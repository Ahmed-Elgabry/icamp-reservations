<?php

namespace App\Repositories;

interface ICopyRepository
{
    
}