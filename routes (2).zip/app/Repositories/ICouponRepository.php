<?php

namespace App\Repositories;

interface ICouponRepository
{
    
}