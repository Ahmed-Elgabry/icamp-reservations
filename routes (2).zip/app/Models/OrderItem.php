<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    protected $guarded = [];
    protected $table = 'order_items';

    public function order() { return $this->belongsTo(Order::class); }
    public function stock() { return $this->belongsTo(Stock::class); }
    public function account() { return $this->belongsTo(BankAccount::class, 'account_id'); }
}
