<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Template</title>

</head>
<body>

<header>
    <div class="header">
    </div>
</header>

<section>
    <div>
        <div class="container">
            <div class="p">
                {{$data['message']}}
            </div>
        </div>
    </div>
</section>

<footer>
    <div class="footer">
    </div>
</footer>

</body>
</html>
