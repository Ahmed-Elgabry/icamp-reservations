<?php

namespace App\Repositories;

interface IInitialPageRepository
{
    
}