<?php

namespace App\Repositories;

interface IOrderRepository
{
    
}