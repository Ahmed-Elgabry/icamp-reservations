<?php

namespace App\Repositories;

interface IBannerRepository
{
    
}