<?php

namespace App\Repositories;

interface IAddressRepository
{
    
}