<?php

namespace App\Repositories;

interface IPermissionRepository
{

}