<?php

namespace App\Repositories;

interface ICityRepository
{
    
}