<?php

namespace App\Repositories;

interface IPackageRepository
{
    
}