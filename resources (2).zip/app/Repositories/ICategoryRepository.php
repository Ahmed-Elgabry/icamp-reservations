<?php

namespace App\Repositories;

interface ICategoryRepository
{
    
}